"""Top-level package for amakihi."""

__author__ = """Nicholas Vieira"""
__email__ = 'nicholas.vieira@mail.mcgill.ca'
__version__ = '0.1.0'
