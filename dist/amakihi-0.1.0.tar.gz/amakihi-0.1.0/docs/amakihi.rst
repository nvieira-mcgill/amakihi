amakihi package
===============

Submodules
----------

amakihi.amakihi module
----------------------

.. automodule:: amakihi.amakihi
   :members:
   :undoc-members:
   :show-inheritance:

amakihi.astroalign\_mod module
------------------------------

.. automodule:: amakihi.astroalign_mod
   :members:
   :undoc-members:
   :show-inheritance:

amakihi.background module
-------------------------

.. automodule:: amakihi.background
   :members:
   :undoc-members:
   :show-inheritance:

amakihi.crop module
-------------------

.. automodule:: amakihi.crop
   :members:
   :undoc-members:
   :show-inheritance:

amakihi.crossmatch module
-------------------------

.. automodule:: amakihi.crossmatch
   :members:
   :undoc-members:
   :show-inheritance:

amakihi.ePSF module
-------------------

.. automodule:: amakihi.ePSF
   :members:
   :undoc-members:
   :show-inheritance:

amakihi.imalign module
----------------------

.. automodule:: amakihi.imalign
   :members:
   :undoc-members:
   :show-inheritance:

amakihi.masking module
----------------------

.. automodule:: amakihi.masking
   :members:
   :undoc-members:
   :show-inheritance:

amakihi.plotting module
-----------------------

.. automodule:: amakihi.plotting
   :members:
   :undoc-members:
   :show-inheritance:

amakihi.query\_2MASS module
---------------------------

.. automodule:: amakihi.query_2MASS
   :members:
   :undoc-members:
   :show-inheritance:

amakihi.query\_CFIS module
--------------------------

.. automodule:: amakihi.query_CFIS
   :members:
   :undoc-members:
   :show-inheritance:

amakihi.query\_DECaLS module
----------------------------

.. automodule:: amakihi.query_DECaLS
   :members:
   :undoc-members:
   :show-inheritance:

amakihi.query\_PS1 module
-------------------------

.. automodule:: amakihi.query_PS1
   :members:
   :undoc-members:
   :show-inheritance:

amakihi.rb\_dataset\_utils module
---------------------------------

.. automodule:: amakihi.rb_dataset_utils
   :members:
   :undoc-members:
   :show-inheritance:

amakihi.rb\_model\_utils module
-------------------------------

.. automodule:: amakihi.rb_model_utils
   :members:
   :undoc-members:
   :show-inheritance:

amakihi.templates module
------------------------

.. automodule:: amakihi.templates
   :members:
   :undoc-members:
   :show-inheritance:

amakihi.transient module
------------------------

.. automodule:: amakihi.transient
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: amakihi
   :members:
   :undoc-members:
   :show-inheritance:
