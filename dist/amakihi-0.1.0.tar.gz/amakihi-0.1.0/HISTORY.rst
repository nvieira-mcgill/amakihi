=======
History
=======

0.1.0 (2023-02-14)
------------------

* First release on PyPI.
