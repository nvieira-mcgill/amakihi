=======
Credits
=======

Development Lead
----------------

* Nicholas Vieira <nicholas.vieira@mail.mcgill.ca>

Contributors
------------

None yet. Why not be the first?
